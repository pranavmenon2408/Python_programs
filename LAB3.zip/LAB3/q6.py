import torch
import torch.nn as nn
import torch.optim as optim
import matplotlib.pyplot as plt

# Step 1: Prepare the data
# Input data (X1, X2) and target output (Y)
X = torch.tensor([[3, 8], [4, 5], [5, 7], [6, 3], [2, 1]], dtype=torch.float32)
Y = torch.tensor([-3.7, 3.5, 2.5, 11.5, 5.7], dtype = torch.float32).view(-1, 1)


# Step 2: Define the Multiple Linear Regression Model using nn.Linear
class MultipleLinearRegressionModel(nn.Module):
    def __init__(self):
        super(MultipleLinearRegressionModel, self).__init__()
        # nn.Linear(in_features, out_features) where input features = 2 (X1, X2) and output features = 1 (Y)
        self.linear = nn.Linear(2, 1)

    def forward(self, x):
        return self.linear(x)


# Step 3: Initialize the model, loss function, and optimizer
model = MultipleLinearRegressionModel()
criterion = nn.MSELoss()  # Mean Squared Error loss
optimizer = optim.SGD(model.parameters(), lr=0.001)  # SGD optimizer with learning rate = 0.001

# Step 4: Training Loop
epochs = 1000  # Number of epochs
losses = []  # To store the loss value after each epoch for plotting

for epoch in range(epochs):
    # Zero the gradients before the backward pass
    optimizer.zero_grad()

    # Forward pass: Compute predicted y by passing X to the model
    y_pred = model(X)

    # Compute the loss
    loss = criterion(y_pred, Y)

    # Backward pass: Compute gradients
    loss.backward()

    # Update the parameters using the optimizer
    optimizer.step()

    # Store the loss value for plotting
    losses.append(loss.item())

    # Optionally print the loss every 100 epochs
    if (epoch + 1) % 100 == 0:
        print(f'Epoch [{epoch + 1}/{epochs}], Loss: {loss.item():.4f}')

# Step 5: Plotting the Loss vs Epochs
plt.plot(range(epochs), losses)
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.title('Loss vs Epochs for Multiple Linear Regression')
plt.grid(True)
plt.show()

# Step 6: Verify the model prediction for X1=3, X2=2
x_test = torch.tensor([[3.0, 2.0]], dtype=torch.float32)
with torch.no_grad():  # Disable gradient calculation
    predicted_y = model(x_test)

print(f"Predicted value of Y for X1=3, X2=2: {predicted_y.item():.4f}")

# Step 7: Print the learned parameters (weights and bias)
print(f"Learned weight (w1): {model.linear.weight[0][0].item():.4f}")
print(f"Learned weight (w2): {model.linear.weight[0][1].item():.4f}")
print(f"Learned bias (b): {model.linear.bias.item():.4f}")
