import torch
import torch.nn as nn
import torch.optim as optim
import matplotlib.pyplot as plt

# Step 1: Prepare the data
x = torch.tensor([1, 5, 10, 10, 25, 50, 70, 75, 100], dtype=torch.float32).view(-1,
                                                                                1)  # reshape for single feature input
y = torch.tensor([0, 0, 0, 0, 0, 1, 1, 1, 1], dtype=torch.float32).view(-1, 1)  # reshaping Y as a column vector


# Step 2: Define the Logistic Regression Model using nn.Linear
class LogisticRegressionModel(nn.Module):
    def __init__(self):
        super(LogisticRegressionModel, self).__init__()
        # One input feature (x) and one output (binary classification)
        self.linear = nn.Linear(1, 1)

    def forward(self, x):
        # Sigmoid activation for binary classification
        return torch.sigmoid(self.linear(x))


# Step 3: Initialize the model, loss function, and optimizer
model = LogisticRegressionModel()
criterion = nn.BCELoss()  # Binary Cross-Entropy Loss for binary classification
optimizer = optim.SGD(model.parameters(), lr=0.001)  # SGD optimizer

# Step 4: Training Loop
epochs = 1000
losses = []

for epoch in range(epochs):
    # Zero the gradients before the backward pass
    optimizer.zero_grad()

    # Forward pass: Compute predicted y (probabilities)
    y_pred = model(x)

    # Compute the loss (binary cross-entropy)
    loss = criterion(y_pred, y)

    # Backward pass: Compute gradients
    loss.backward()

    # Update the parameters using the optimizer
    optimizer.step()

    # Store the loss for plotting
    losses.append(loss.item())

    # Optionally print the loss every 100 epochs
    if (epoch + 1) % 100 == 0:
        print(f'Epoch [{epoch + 1}/{epochs}], Loss: {loss.item():.4f}')

# Step 5: Plotting the Loss vs Epochs
plt.plot(range(epochs), losses)
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.title('Loss vs Epochs for Logistic Regression')
plt.grid(True)
plt.show()

# Step 6: Make predictions on the training data
with torch.no_grad():  # Disable gradient calculation for inference
    y_pred_class = model(x).round()  # Round the probabilities to get binary class predictions

print("Predictions on the training data (rounded to 0 or 1):")
print(y_pred_class)

# Step 7: Plot the data points and the logistic regression curve
x_range = torch.linspace(0, 110, 100).view(-1, 1)  # Generate points for plotting the decision boundary
with torch.no_grad():
    y_range = model(x_range)

plt.scatter(x.numpy(), y.numpy(), color='blue', label='Data points')
plt.plot(x_range.numpy(), y_range.numpy(), color='red', label='Logistic regression curve')
plt.xlabel('x')
plt.ylabel('y')
plt.title('Logistic Regression Model')
plt.legend()
plt.grid(True)
plt.show()

# Step 8: Print learned parameters (weight and bias)
print(f"Learned weight (w): {model.linear.weight.item():.4f}")
print(f"Learned bias (b): {model.linear.bias.item():.4f}")
