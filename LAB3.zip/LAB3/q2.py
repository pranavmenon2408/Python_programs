import torch

# Input data (x) and target values (y)
x = torch.tensor([2.0, 4.0])  # Input features (dtype=torch.float)
y = torch.tensor([20.0, 40.0])  # Target values (dtype=torch.float)

# Initialize parameters (w and b) with requires_grad=True to track gradients
w = torch.tensor(1.0, requires_grad=True)  # Initial weight
b = torch.tensor(1.0, requires_grad=True)  # Initial bias

# Learning rate
learning_rate = 0.001

# Number of epochs
epochs = 2

# Gradient Descent Loop
for epoch in range(epochs):
    # Compute the predicted y (y_pred)
    y_pred = w * x + b

    # Compute the loss (Mean Squared Error)
    loss = torch.mean((y_pred - y) ** 2)

    # Compute gradients using PyTorch (backpropagation)
    loss.backward()

    # Analytical gradient calculation for w and b
    w_grad_analytical = torch.sum((y_pred - y) * x)  # Gradient with respect to w
    b_grad_analytical = torch.sum(y_pred - y)  # Gradient with respect to b

    # Print both the PyTorch computed gradients and the analytical gradients
    print(f"Epoch {epoch + 1}:")
    print(f"PyTorch - w.grad = {w.grad.item()} | b.grad = {b.grad.item()}")
    print(f"Analytical - w_grad = {w_grad_analytical.item()} | b_grad = {b_grad_analytical.item()}")

    # Update parameters using gradient descent (PyTorch)
    with torch.no_grad():  # Disable gradient tracking for parameter updates
        w -= learning_rate * w.grad
        b -= learning_rate * b.grad

    # Print updated parameters and loss (PyTorch update)
    print(f"Updated w (PyTorch) = {w.item()}")
    print(f"Updated b (PyTorch) = {b.item()}")
    print(f"Loss (PyTorch) = {loss.item()}")

    # Zero the gradients for the next epoch
    w.grad.zero_()
    b.grad.zero_()

    # Print a separator line for clarity
    print("-" * 40)
